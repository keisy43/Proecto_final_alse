var searchData=
[
  ['verificarpaciente',['verificarpaciente',['../classdb__local.html#af39c3f536549485b9ec8e614f92870c1',1,'db_local']]],
  ['verificarusuario',['verificarusuario',['../classdb__local.html#a54ef2e3aa44fcfb68f9dd02c64ae8421',1,'db_local']]]
];
