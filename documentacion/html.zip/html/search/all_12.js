var searchData=
[
  ['_7eaciertos',['~aciertos',['../classaciertos.html#aef1c2b79f77ef192dd48a2359c78b83d',1,'aciertos']]],
  ['_7emenu',['~menu',['../classmenu.html#a5efbd22f23289b42ed68d2a9bb431f35',1,'menu']]],
  ['_7epaciente',['~paciente',['../classpaciente.html#aa2c0443ac761e3c01437ec3b051b1e5a',1,'paciente']]],
  ['_7eprueba',['~prueba',['../classprueba.html#a10ec83347646102027f40a34f8cc9688',1,'prueba']]],
  ['_7eregpc',['~regpc',['../classregpc.html#a44345c70fea1c353bde3cd00e4a05c1d',1,'regpc']]],
  ['_7eregu',['~regu',['../classregu.html#af4ce8301d06b2636e666ac5c9cf46e36',1,'regu']]],
  ['_7etiempod',['~tiempod',['../classtiempod.html#a5107437d6cac97c1b63c3ff9df5a9e36',1,'tiempod']]],
  ['_7eusuario',['~usuario',['../classusuario.html#aa70d0ad5fba6586c37b429b1806ff672',1,'usuario']]]
];
