var searchData=
[
  ['fn',['fn',['../classregpc.html#a0db133a320356ff6a456cee7f2d34720',1,'regpc::fn()'],['../classregu.html#ae71ceda1a90a9836dbf263eaa3bf9a84',1,'regu::fn()']]]
];
