var searchData=
[
  ['insertar',['insertar',['../classprueba.html#ac7bf490420a1bd8080157ce2e2d6b78c',1,'prueba']]]
];
