var searchData=
[
  ['lastname',['lastname',['../classregu.html#a676bef339cfb36f368ca41f2089268d1',1,'regu']]]
];
