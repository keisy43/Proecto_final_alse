var searchData=
[
  ['name',['name',['../classregu.html#a5f9ec0ff54143b14c6cd04f360c04d2c',1,'regu']]],
  ['ningresos',['ningresos',['../classregpc.html#a3634b2c40b40e029561728334d2a6b72',1,'regpc']]],
  ['nombre',['nombre',['../classregpc.html#a95b954b79eb473167a8e631833d756ad',1,'regpc']]]
];
