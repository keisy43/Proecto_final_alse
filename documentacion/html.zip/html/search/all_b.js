var searchData=
[
  ['paciente',['paciente',['../classpaciente.html',1,'paciente'],['../classpaciente.html#ad0ccef0b1f9db88970e6c748988cdf68',1,'paciente::paciente()']]],
  ['prueba',['prueba',['../classprueba.html',1,'prueba'],['../classprueba.html#a24f54c7bdd250ae7c191204b6640e76a',1,'prueba::prueba()']]]
];
