var searchData=
[
  ['regpc',['regpc',['../classregpc.html',1,'regpc'],['../classregpc.html#a0e746dd80042db7863f1acc0eceb3e0e',1,'regpc::regpc()']]],
  ['regu',['regu',['../classregu.html',1,'regu'],['../classregu.html#a4233920e912063eba919a7031cadc10a',1,'regu::regu()']]],
  ['resultados',['resultados',['../classprueba.html#ad26285fa9b7055591708f9a31223353b',1,'prueba']]],
  ['rz',['rz',['../classregpc.html#a76fa61f1dbcfb75c08707c4c9cb71b43',1,'regpc']]]
];
