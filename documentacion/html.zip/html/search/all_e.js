var searchData=
[
  ['setcontra',['setContra',['../classusuario.html#a8e027d694579ff05152cc77c50886111',1,'usuario']]],
  ['setdoci',['setDoci',['../classpaciente.html#a98b1eb1d2344fde9ea082722eecd980a',1,'paciente']]],
  ['setnombre',['setNombre',['../classpaciente.html#aa1c002ee279da1512c06a30ab6f36cf8',1,'paciente']]],
  ['setuser',['setUser',['../classusuario.html#a0dc83a4f7544e487109854604f167e94',1,'usuario']]]
];
