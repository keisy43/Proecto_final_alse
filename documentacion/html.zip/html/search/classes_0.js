var searchData=
[
  ['aciertos',['aciertos',['../classaciertos.html',1,'']]]
];
