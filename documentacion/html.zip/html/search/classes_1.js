var searchData=
[
  ['db_5flocal',['db_local',['../classdb__local.html',1,'']]]
];
