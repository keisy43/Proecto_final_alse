var searchData=
[
  ['paciente',['paciente',['../classpaciente.html',1,'']]],
  ['prueba',['prueba',['../classprueba.html',1,'']]]
];
