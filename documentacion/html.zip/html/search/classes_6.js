var searchData=
[
  ['usuario',['usuario',['../classusuario.html',1,'']]]
];
