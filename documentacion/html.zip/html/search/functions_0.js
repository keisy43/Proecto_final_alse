var searchData=
[
  ['abrirdb',['abrirDB',['../classdb__local.html#a64ad8edee1a11c82f5d96bfd10a5fdd3',1,'db_local']]],
  ['aciertos',['aciertos',['../classaciertos.html#a46e28661870e72ccb00b558478420f64',1,'aciertos']]]
];
