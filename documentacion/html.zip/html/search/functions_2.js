var searchData=
[
  ['getcontra',['getContra',['../classusuario.html#ae8abb797a4efda6053b2c15936ba9792',1,'usuario']]],
  ['getdoci',['getDoci',['../classpaciente.html#a35eb76c2a62bf5942a81f3ab0dfa7ae6',1,'paciente']]],
  ['getnombre',['getNombre',['../classpaciente.html#ade5b611666a067d54d8cee91bf737f2a',1,'paciente']]],
  ['getuser',['getUser',['../classusuario.html#a0a32493a53b4aed9d66662f8e6839889',1,'usuario']]]
];
