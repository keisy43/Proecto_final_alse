var searchData=
[
  ['regpc',['regpc',['../classregpc.html#a0e746dd80042db7863f1acc0eceb3e0e',1,'regpc']]],
  ['regu',['regu',['../classregu.html#a4233920e912063eba919a7031cadc10a',1,'regu']]],
  ['resultados',['resultados',['../classprueba.html#ad26285fa9b7055591708f9a31223353b',1,'prueba']]]
];
