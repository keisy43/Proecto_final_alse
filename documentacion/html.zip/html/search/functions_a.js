var searchData=
[
  ['usuario',['usuario',['../classusuario.html#a34821186e90424c9105221fb931e9ca0',1,'usuario']]]
];
