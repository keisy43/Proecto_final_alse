var searchData=
[
  ['contra',['contra',['../classregu.html#a5293f6cb33494cf1701c643b2ff17b4b',1,'regu']]]
];
