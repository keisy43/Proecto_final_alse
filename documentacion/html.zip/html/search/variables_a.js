var searchData=
[
  ['user',['user',['../classregu.html#a22cc21aa95246c8b198c0e43dc932c9b',1,'regu']]]
];
